package com.shawonarefin.cse215.sp2021.assignment03.ver01;

import java.util.Calendar;
import java.util.Date;
import java.util.Scanner;

public class GenerateRandomPassportInfo {
  private final static int NUMBER_OF_IDS = 15;
  private final static int ALPHABET_RANGE = 26;
  private final static int DIGIT_RANGE = 10;
  private final static int PASSPORT_CHAR_RANGE = 2;
  private final static int PASSPORT_DIGIT_RANGE = 7;
  private final static int NID_LENGTH = 10;
  private final static int STARTING_YEAR = 1940;
  private final static int ENDING_YEAR = 2000;
  private final static int DATE_RANGE = 7;
  private final static int WEEK_RANGE = 52;


  private static String[] sPassportNoArr = new String[NUMBER_OF_IDS];
  private static String[] sNIDNoArr = new String[NUMBER_OF_IDS];
  private static String[] sFirstNameArr = {
    "David", "John","Paul", "Mark", "James", "Andrew", "Scott", "Steven","Robert","Stephen",
    "William","Craig","Michael","Stuart","Christopher", "Alan","Colin","Brian","Kevin","Gary",
    "Richard","Derek","Martin","Thomas","Neil", "Barry","Ian","Jason","Iain","Gordon",
    "Alexander","Graeme","Peter","Darren","Graham", "George","Kenneth","Allan","Simon","Douglas",
    "Keith","Lee","Anthony","Grant","Ross", "Jonathan","Gavin","Nicholas","Joseph","Stewart"
  };
  private static String[] sLastNameArr = {
    "Angus", "Russell", "Cameron", "Roderick", "Norman", "Murray", "Gareth", "Dean", "Eric", "Adrian",
    "Gregor", "Samuel", "Gerald", "Henry", "Justin", "Benjamin", "Shaun", "Callum", "Campbell", "Frank",
    "Roy", "Timothy", "David", "John", "Paul", "James", "Mark", "Scott", "Andrew", "Steven",
    "Robert", "Stephen", "Craig", "Christopher", "Alan", "Michael", "Stuart", "William", "Kevin", "Colin",
    "Brian", "Derek", "Neil", "Richard", "Gary", "Barry", "Martin","Thomas","Ian","Gordon"
  };
  private static int sIndex = 0;

  private static char getRandomChar(){
    char ch = 'A';
    int offset = (int)(Math.random()* ALPHABET_RANGE);
    return (char) (ch+offset);
  }
  private static int getRandomDigit(){
    return ((int)(Math.random()*DIGIT_RANGE));
  }
  private static int getRandomNonZeroDigit(){
    int offset = 1;
    return (((int)(Math.random()*(DIGIT_RANGE-offset)))+offset);
  }
  private static String getNewRandomPassportNumber(){
    int passportCharIndex = 0;
    StringBuilder sb = new StringBuilder();
    for(int idx = 0; idx < PASSPORT_CHAR_RANGE; idx++){
      sb.append(getRandomChar());
    }
    for(int idx = 0; idx < PASSPORT_DIGIT_RANGE; idx++){
      sb.append(getRandomDigit());
    }

    return sb.toString();
  }
  private static String getNewRandomNIDNumber(){
    StringBuilder sb = new StringBuilder();
    for(int idx = 0; idx < NID_LENGTH; idx++){
      if(idx > 0 && idx%3==0 && idx<=6){
        sb.append("-");
      }
      if(idx==0)
        sb.append(getRandomNonZeroDigit());
      else
        sb.append(getRandomDigit());
    }

    return sb.toString();
  }
  private static String getUniquePassportNumber(){
    boolean notUnique = false;
    String passportNo = null;
    do {
      passportNo = getNewRandomPassportNumber();
      for(int i = 0; i< sIndex; i++){
         if(passportNo.equals(sPassportNoArr[i])){
           notUnique = true;
         }
      }
    }while (notUnique);
    return passportNo;
  }
  private static String getUniqueNIDNumber(){
    boolean notUnique = false;
    return getNewRandomNIDNumber();
  }
  private static String getRandomFirstName(){
    int idx = ((int)(Math.random()*(sFirstNameArr.length)));
    return sFirstNameArr[idx];
  }
  private static String getRandomLastName(){
    int idx = ((int)(Math.random()*(sLastNameArr.length)));
    return sLastNameArr[idx];
  }
  private static Date getRandomDOB(){
    int weekYear = (STARTING_YEAR
      + (int)(Math.random()*(ENDING_YEAR-STARTING_YEAR)));

    int dayOfWeek =  (((int)(Math.random()* DATE_RANGE))+1);
    int weekOfYear =  (((int)(Math.random()* WEEK_RANGE))+1);
    Calendar calendar = Calendar.getInstance();
    calendar.setWeekDate(weekYear, weekOfYear, dayOfWeek);
    return calendar.getTime();
  }

  public static PassportInfo getUniquePassportInfo(){
    PassportInfo info = null;
    if(sIndex < NUMBER_OF_IDS) {
      String passportID = getUniquePassportNumber();
      String nid = getUniqueNIDNumber();
      sPassportNoArr[sIndex] = passportID;
      sNIDNoArr[sIndex] = nid;
      sIndex++;
      info = PassportInfo.builder(passportID, nid);
      info.setFirstName(getRandomFirstName());
      info.setLastName(getRandomLastName());
      info.setDateOfBirth(getRandomDOB());
    }
    return info;
  }

  public static void main(String[] args) {
    PassportInfo[] arr = new PassportInfo[NUMBER_OF_IDS];
    for(int idx = 0; idx < NUMBER_OF_IDS; idx++){
      arr[idx] = getUniquePassportInfo();
      System.out.println(arr[idx]);
    }

    System.out.print("Enter NID: ");
    Scanner input = new Scanner(System.in);
    String nidInput = input.next();

    boolean found = false;
    for(PassportInfo info : arr){
      if(nidInput.equals(info.getNID())){
        found = true;
        System.out.println("Found ");
        System.out.println(info);
      }
    }

    if(!found){
      System.out.println("Passport not found");
    }
  }
}
