package com.shawonarefin.cse215.sp2021.assignment03.ver01;

import java.text.DateFormat;
import java.util.Date;
import java.util.Locale;

public class PassportInfo {
  private String mPassportNumber;
  private String mFirstName;
  private String mLastName;
  private String mNID;
  private Date mDateOfBirth;
  private Picture mPicture;

  private final static DateFormat sDateFormat = DateFormat.getDateInstance(DateFormat.DATE_FIELD,
    new Locale("en","US"));

  private PassportInfo(String passport, String nid){
    this.mPassportNumber = passport;
    this.mNID = nid;
  }
  public static PassportInfo builder(String passport, String nid){
    PassportInfo newPassport = new PassportInfo(passport,nid);
    newPassport.mPicture = (new Picture());
    return newPassport;
  }

  public void setFirstName(String mFirstName) {
    this.mFirstName = mFirstName;
  }
  public void setLastName(String mLastName) {
    this.mLastName = mLastName;
  }
  public void setDateOfBirth(Date mDateOfBirth) {
    this.mDateOfBirth = mDateOfBirth;
  }

  public String getPassportNumber() {
    return mPassportNumber;
  }
  public String getNID() {
    return mNID;
  }
  public String getLastName() {
    return mLastName;
  }
  public String getFirstName() {
    return mFirstName;
  }
  public Picture getPicture() {
    return mPicture;
  }
  public Date getDateOfBirth() {
    return mDateOfBirth;
  }

  @Override
  public String toString() {
    return "{" + "\n" +
      "\tPassport # : \'" + mPassportNumber + "\',\n" +
      "\tFirst Name : \'" + mFirstName + "\',\n" +
      "\tLast Name : \'" + mLastName + "\',\n" +
      "\tNID : \'" + mNID + "\',\n" +
      "\tDate Of Birth : \'" + sDateFormat.format(mDateOfBirth) + "\',\n" +
      "\tPicture : \n" + mPicture +
      '}';
  }

  public static void main(String[] args) {
    PassportInfo info = PassportInfo.builder("ABC","XYZ");
    System.out.println(info);
  }
}
