package com.shawonarefin.cse215.sp2021.assignment03.ver01;

class Pixel{
  private final static int OFFSET = 128;
  private final static int RANGE = 256;

  private byte mRed;
  private byte mBlue;
  private byte mGreen;

  private static byte randomByte(){
    return (byte) ((int)(Math.random()*RANGE)-OFFSET);
  }

  public Pixel(){
    mRed = randomByte();
    mBlue = randomByte();
    mGreen = randomByte();
  }
  public int getRedValue(){
    return ((int)(mRed)+OFFSET);
  }
  public int getBlueValue(){
    return ((int)(mBlue)+OFFSET);
  }
  public int getGreenValue(){
    return ((int)(mGreen)+OFFSET);
  }

  @Override
  public String toString() {
    return "{" +
      "r = " + getRedValue() +
      ", g = " + getBlueValue() +
      ", b = " + getGreenValue() +
      "} ";
  }
}

public class Picture {
  private static final int ROW_SIZE = 40;
  private static final int COL_SIZE = 50;
  private Pixel[][] mPixelArray;
  private String mString;

  public Picture(){
    mPixelArray = new Pixel[ROW_SIZE][COL_SIZE];
    for (int row=0; row<mPixelArray.length; row++){
      for(int col=0; col<mPixelArray[row].length; col++){
        mPixelArray[row][col] = new Pixel();
      }
    }

    StringBuilder sb = new StringBuilder();
    for(Pixel[] row: mPixelArray){
      for(Pixel pixel: row){
        sb.append(pixel.toString());
      }
      sb.append("\n");
    }
    mString = sb.toString();
  }

  @Override
  public String toString() {
    return mString;
  }

  public void getPicture(){
    System.out.println(mString);
  }

  public static void main(String[] args) {
    Picture picture = new Picture();
    picture.getPicture();
  }
}
