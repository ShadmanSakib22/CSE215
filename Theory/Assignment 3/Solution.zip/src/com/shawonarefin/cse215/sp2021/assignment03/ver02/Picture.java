package com.shawonarefin.cse215.sp2021.assignment03.ver02;

import java.awt.image.BufferedImage;

public class Picture {
  private static final int ROW_SIZE = 40;
  private static final int COL_SIZE = 50;
  private BufferedImage mImage;

  public Picture(){
    mImage = new BufferedImage(COL_SIZE, ROW_SIZE, BufferedImage.TYPE_INT_ARGB);
    for(int y=0; y<COL_SIZE; y++){
      for(int x=0; x<ROW_SIZE; x++){
        int a = (int)(Math.random()*256); //alpha
        int r = (int)(Math.random()*256); //red
        int g = (int)(Math.random()*256); //green
        int b = (int)(Math.random()*256); //blue
        int p = (a<<24) | (r<<16) | (g<<8) | b;
        mImage.setRGB(y, x, p);
      }
    }
  }

  @Override
  public String toString() {
    return mImage.toString();
  }
  public BufferedImage getPicture(){
    return mImage;
  }
}
